exports.vnMenu = [
"https://huggingface.co/spaces/API-XX/TEST/resolve/main/Links/menu.mp3",
"https://huggingface.co/spaces/API-XX/TEST/resolve/main/Links/menu.mp3",
"https://huggingface.co/spaces/API-XX/TEST/resolve/main/Links/menu.mp3"
]
exports.images = [
        'https://huggingface.co/spaces/API-XX/TEST/resolve/main/Links/menu.jpg',
        'https://huggingface.co/spaces/API-XX/TEST/resolve/main/Links/menu.jpg',
        'https://huggingface.co/spaces/API-XX/TEST/resolve/main/Links/menu.jpg'
    ];
