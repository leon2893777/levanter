const pairNumber = "447893927239";

const accNumber = ""

const name = ""

const bankName = ""

const any = "𓃠"

const emoji = '☘️'
module.exports = { pairNumber, accNumber, bankName, name, any, emoji };