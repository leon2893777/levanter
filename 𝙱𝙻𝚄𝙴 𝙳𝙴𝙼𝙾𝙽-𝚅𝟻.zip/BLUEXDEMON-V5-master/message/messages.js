exports.bad = [
    "werey", "ode", "mumu", "fool", "fuu", "mad", "crazy", "dumb", "dumbass", "bitch", 
    "whore", "hd", "bangsat", "gblk", "tolol", "peler", "pler", "2k", "asw", "asu", 
    "babi", "asshole", "nigga", "bast", "fuck", "shit", "damn", "asshole", "bastard",
    "dick", "cock", "cunt", "slut", "pussy", "fag", "retard", "nigger", "chink", "spic",
    "kike", "gook", "dyke", "jap", "raghead", "bimbo", "whorehouse", "sex", "porn", 
    "bastardo", "biatch", "shithead", "douchebag", "motherfucker", "cocksucker", "freaking",
    "jackass", "bitchass", "fucker", "cum", "skank", "whorebag", "piss", "penis", "vagina", 
    "tits", "clit", "dildo", "anal", "piss off", "slutbag", "jizz", "mangina", "beach", 
    "buttfuck", "blowjob", "bukkake", "cumshot", "dickhead", "fisted", "gimp", "slutty", 
    "cockhead", "testicles", "cuntface", "twat", "prick", "assclown", "asswipe", "asslick", 
    "nutbag", "pussyhole", "rimming", "sodomy", "toilet", "fisting", "panty", "boobs", 
    "pecker", "ballz", "pussylicker", "pissface", "shitter", "spunk", "bukkake", "faggy", 
    "cocktease", "lesbo", "hoe", "shemale", "tranny", "zebra", "dyke", "bastad", "balllicker", "cumshot"
];